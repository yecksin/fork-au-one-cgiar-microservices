export class SubscribeApplicationDto {
  public acronym: string;
  public environment: string;
}
