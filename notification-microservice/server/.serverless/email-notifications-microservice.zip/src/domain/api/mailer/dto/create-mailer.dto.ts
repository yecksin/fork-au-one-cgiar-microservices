export class CreateMailerDto {}
