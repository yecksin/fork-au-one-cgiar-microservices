export enum SlackChannelsEnum {
  MICROSERVICES_NOTIFICATIONS = '#microservices-notifications',
}
