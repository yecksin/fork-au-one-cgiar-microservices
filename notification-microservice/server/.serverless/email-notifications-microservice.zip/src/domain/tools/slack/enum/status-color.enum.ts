export enum StatusColorEnum {
  ERROR = '#FF0000',
  SUCCESS = '#00FF00',
  WARNING = '#FFFF00',
}
