export class ResponseClarisaDtio<T> {
  message: string;
  status: number;
  response: T;
}
