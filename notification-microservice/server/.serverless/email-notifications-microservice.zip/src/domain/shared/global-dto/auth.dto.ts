export class AuthorizationDto {
  public username: string;
  public password: string;
}
